/****************************************************************************
** Meta object code from reading C++ file 'brainstorm.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.9.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../Client/brainstorm.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'brainstorm.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.9.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_BrainStorm_t {
    QByteArrayData data[21];
    char stringdata0[397];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_BrainStorm_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_BrainStorm_t qt_meta_stringdata_BrainStorm = {
    {
QT_MOC_LITERAL(0, 0, 10), // "BrainStorm"
QT_MOC_LITERAL(1, 11, 21), // "on_RankButton_clicked"
QT_MOC_LITERAL(2, 33, 0), // ""
QT_MOC_LITERAL(3, 34, 23), // "on_SingleButton_clicked"
QT_MOC_LITERAL(4, 58, 21), // "on_SingleBack_clicked"
QT_MOC_LITERAL(5, 80, 22), // "on_SingleStart_clicked"
QT_MOC_LITERAL(6, 103, 21), // "receiveSingleQuestion"
QT_MOC_LITERAL(7, 125, 4), // "json"
QT_MOC_LITERAL(8, 130, 14), // "SingleTimerOut"
QT_MOC_LITERAL(9, 145, 19), // "on_OverBack_clicked"
QT_MOC_LITERAL(10, 165, 24), // "on_SingleButtonA_clicked"
QT_MOC_LITERAL(11, 190, 24), // "on_SingleButtonB_clicked"
QT_MOC_LITERAL(12, 215, 24), // "on_SingleButtonC_clicked"
QT_MOC_LITERAL(13, 240, 24), // "on_SingleButtonD_clicked"
QT_MOC_LITERAL(14, 265, 4), // "Rank"
QT_MOC_LITERAL(15, 270, 12), // "RankTimerOut"
QT_MOC_LITERAL(16, 283, 22), // "on_RankButtonA_clicked"
QT_MOC_LITERAL(17, 306, 22), // "on_RankButtonB_clicked"
QT_MOC_LITERAL(18, 329, 22), // "on_RankButtonC_clicked"
QT_MOC_LITERAL(19, 352, 22), // "on_RankButtonD_clicked"
QT_MOC_LITERAL(20, 375, 21) // "on_overButton_clicked"

    },
    "BrainStorm\0on_RankButton_clicked\0\0"
    "on_SingleButton_clicked\0on_SingleBack_clicked\0"
    "on_SingleStart_clicked\0receiveSingleQuestion\0"
    "json\0SingleTimerOut\0on_OverBack_clicked\0"
    "on_SingleButtonA_clicked\0"
    "on_SingleButtonB_clicked\0"
    "on_SingleButtonC_clicked\0"
    "on_SingleButtonD_clicked\0Rank\0"
    "RankTimerOut\0on_RankButtonA_clicked\0"
    "on_RankButtonB_clicked\0on_RankButtonC_clicked\0"
    "on_RankButtonD_clicked\0on_overButton_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_BrainStorm[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      18,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  104,    2, 0x08 /* Private */,
       3,    0,  105,    2, 0x08 /* Private */,
       4,    0,  106,    2, 0x08 /* Private */,
       5,    0,  107,    2, 0x08 /* Private */,
       6,    1,  108,    2, 0x08 /* Private */,
       8,    0,  111,    2, 0x08 /* Private */,
       9,    0,  112,    2, 0x08 /* Private */,
      10,    0,  113,    2, 0x08 /* Private */,
      11,    0,  114,    2, 0x08 /* Private */,
      12,    0,  115,    2, 0x08 /* Private */,
      13,    0,  116,    2, 0x08 /* Private */,
      14,    1,  117,    2, 0x08 /* Private */,
      15,    0,  120,    2, 0x08 /* Private */,
      16,    0,  121,    2, 0x08 /* Private */,
      17,    0,  122,    2, 0x08 /* Private */,
      18,    0,  123,    2, 0x08 /* Private */,
      19,    0,  124,    2, 0x08 /* Private */,
      20,    0,  125,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QJsonObject,    7,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QJsonObject,    7,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void BrainStorm::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        BrainStorm *_t = static_cast<BrainStorm *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->on_RankButton_clicked(); break;
        case 1: _t->on_SingleButton_clicked(); break;
        case 2: _t->on_SingleBack_clicked(); break;
        case 3: _t->on_SingleStart_clicked(); break;
        case 4: _t->receiveSingleQuestion((*reinterpret_cast< QJsonObject(*)>(_a[1]))); break;
        case 5: _t->SingleTimerOut(); break;
        case 6: _t->on_OverBack_clicked(); break;
        case 7: _t->on_SingleButtonA_clicked(); break;
        case 8: _t->on_SingleButtonB_clicked(); break;
        case 9: _t->on_SingleButtonC_clicked(); break;
        case 10: _t->on_SingleButtonD_clicked(); break;
        case 11: _t->Rank((*reinterpret_cast< QJsonObject(*)>(_a[1]))); break;
        case 12: _t->RankTimerOut(); break;
        case 13: _t->on_RankButtonA_clicked(); break;
        case 14: _t->on_RankButtonB_clicked(); break;
        case 15: _t->on_RankButtonC_clicked(); break;
        case 16: _t->on_RankButtonD_clicked(); break;
        case 17: _t->on_overButton_clicked(); break;
        default: ;
        }
    }
}

const QMetaObject BrainStorm::staticMetaObject = {
    { &QDialog::staticMetaObject, qt_meta_stringdata_BrainStorm.data,
      qt_meta_data_BrainStorm,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *BrainStorm::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *BrainStorm::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_BrainStorm.stringdata0))
        return static_cast<void*>(const_cast< BrainStorm*>(this));
    return QDialog::qt_metacast(_clname);
}

int BrainStorm::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 18)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 18;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 18)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 18;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
